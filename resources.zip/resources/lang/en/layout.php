<?php

return [
  'dir' => 'ltr',
  'lang' => 'en',
];
