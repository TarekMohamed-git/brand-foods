<?php

return [
  'dir' => 'rtl',
  'lang' => 'ar',
];
